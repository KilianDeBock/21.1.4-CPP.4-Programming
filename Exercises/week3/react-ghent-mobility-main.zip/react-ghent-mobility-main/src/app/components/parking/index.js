import ParkingGaragesRealtime from './ParkingGaragesRealtime';
import PRRealtime from './PRRealtime';

export {
  ParkingGaragesRealtime,
  PRRealtime,
};