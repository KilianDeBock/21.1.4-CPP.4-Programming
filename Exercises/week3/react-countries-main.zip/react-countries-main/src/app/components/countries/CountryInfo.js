const CountryInfo = ({ country }) => {
  return (
    <div>
      {country.capitalCity}
    </div>
  )
}

export default CountryInfo;